package uk.ac.rhul.cs2800.model;

import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.Test;

/**
 * A class for Testing the registration.
 */
public class RegistrationTest {
  @Test
  void registrationModuleTest() {
    Student student = new Student();
    Module softwarEng = new Module();

    Registration registration = new Registration(student, softwarEng);
    
    assertEquals(softwarEng, registration.getModule());
    assertEquals(student, registration.getStudent());



  }

}
