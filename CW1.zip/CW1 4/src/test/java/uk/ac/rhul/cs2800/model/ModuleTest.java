package uk.ac.rhul.cs2800.model;

import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.Test;

/**
 * a Module test class.
 */
public class ModuleTest {

  @Test
  void moduleTest() {
    Module module = new Module();
    module.setCode("CS2800");
    module.setName("software engeneer");
    module.setMnc(true);

    assertEquals("CS2800", module.getCode());
    assertEquals("software engeneer", module.getName());
    assertEquals(true, module.isMnc());

  }

  @Test
  void secondConstructorTest() {
    Module module = new Module("CS2800", "Soft Eng", false);
    assertEquals("CS2800", module.getCode());
    assertEquals("Soft Eng", module.getName());
    assertEquals(false, module.isMnc());
  }
}
