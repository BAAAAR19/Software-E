package uk.ac.rhul.cs2800.model;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import org.junit.jupiter.api.Test;
import uk.ac.rhul.cs2800.exception.NoGradeAvailableException;
import uk.ac.rhul.cs2800.exception.NoRegistrationException;

/**
 * testing the Student class.
 */
public class TestStudent {
  @Test
  void computeAverageTest() throws NoGradeAvailableException {

    // Test 1
    Student student = new Student();
    student.addGrade(new Grade(40));
    student.addGrade(new Grade(60));

    assertEquals(50, student.computeAverage());
  }

  @Test
  void noGradeAvailableExceptionTest() {
    // Test 2
    assertThrows(NoGradeAvailableException.class, () -> {
      Student student = new Student();
      student.computeAverage();
    });

  }

  @Test
  void studentAtrributTest() {
    // Test 3
    Student student = new Student();
    student.setId(122);
    student.setFirstName("Souheil");
    student.setLastName("Adda-ouadah");
    student.setEmail("an email");
    student.setUsername("Jostar");

    assertEquals(122, student.getId());
    assertEquals("Souheil", student.getFirstName());
    assertEquals("Adda-ouadah", student.getLastName());
    assertEquals("an email", student.getEmail());
    assertEquals("Jostar", student.getUsername());
  }

  @Test
  // Test 4
  void getGradeTest() throws NoGradeAvailableException, NoRegistrationException {
    Module softwarEng = new Module("CS2800", "Soft Eng", true);
    Module math = new Module("CS2700", "Math", false);

    Student student = new Student();
    // added from the register method.
    student.registerModule(math);
    student.registerModule(softwarEng);

    student.addGrade(new Grade(50, softwarEng));
    student.addGrade(new Grade(100, math));


    assertEquals(50, student.getGrade(softwarEng).getScore());
    assertEquals(100, student.getGrade(math).getScore());

  }

  @Test
  // Test 5
  void noGradesAvailableException() {
    assertThrows(NoGradeAvailableException.class, () -> {
      Student student = new Student();
      Module softwarEng = new Module("CS2800", "Soft Eng", true);
      student.getGrade(softwarEng).getScore();
    });
  }

  @Test
  void noRegistrationaAvailableTest() {
    assertThrows(NoRegistrationException.class, () -> {
      Student student = new Student();
      Module softwarEng = new Module();
      student.registerModule(softwarEng);
      student.registerModule(softwarEng);

    });
  }



}
