package uk.ac.rhul.cs2800.model;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertNull;
import org.junit.jupiter.api.Test;

/**
 * Testing the Grade class.
 */
public class GradeTest {

  @Test
  void gradeTest() {
    // Test 1
    Grade grade = new Grade();
    grade.setScore(50);
    assertEquals(50, grade.getScore());
  }

  /**
   * Testing the constructor that sets the score, defaulting the module to null.
   */
  @Test
  void newConstructorTest() {
    // Test 2
    Grade grade = new Grade(50);
    assertEquals(50, grade.getScore());
  }

  /**
   * Tests the constructor that sets both the score and the module.
   */
  @Test
  void getModuleTest() {
    Module module = new Module("CS2800", "Soft Eng", true);
    Grade grade = new Grade(50, module);

    assertEquals("CS2800", grade.getModule().getCode());
    assertEquals("Soft Eng", grade.getModule().getName());
    assertEquals(true, grade.getModule().isMnc());
  }

  /**
   * Test for verifying the IllegalArgumentException when a score is set outside the valid range.
   */
  @Test
  void setScoreExceptionTest() {
    Grade grade = new Grade();
    // Test setting an invalid low score
    assertThrows(IllegalArgumentException.class, () -> grade.setScore(-1), "Score must be between 0 and 100");

    // Test setting an invalid high score
    assertThrows(IllegalArgumentException.class, () -> grade.setScore(101), "Score must be between 0 and 100");
  }

  /**
   * Test to ensure that the module can be null if not set.
   */
  @Test
  void nullModuleTest() {
    Grade grade = new Grade(85); // Using the constructor that defaults module to null
    assertNull(grade.getModule(), "Module should be null when not explicitly set");
  }
}
