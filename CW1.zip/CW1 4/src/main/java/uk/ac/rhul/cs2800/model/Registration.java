package uk.ac.rhul.cs2800.model;

/**
 * Represents a registration linking a student to a module.
 */
public class Registration {
  private Student student;
  private Module module;

  /**
   * Creates a new registration associating a student with a module.
   *
   * @param student the student who is registring 
   * @param module the module thqt the student is registring to 
   */
  public Registration(Student student, Module module) {
    this.student = student;
    this.module = module;
  }

  /**
   * Returns the module associated with this registration.
   *
   * @return module ( registration one )
   */
  public Module getModule() {
    return module;
  }

  /**
   * Returns the student associated with this registration.
   *
   * @return the studentwho registred 
   */
  public Student getStudent() {
    return student;
  }
}
