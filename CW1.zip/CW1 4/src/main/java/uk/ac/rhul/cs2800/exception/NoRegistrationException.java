package uk.ac.rhul.cs2800.exception;

// No registration class.
 
public class NoRegistrationException extends Exception {
   // The serial UID.
  private static final long serialVersionUID = 1L;

}
