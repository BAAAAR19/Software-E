package uk.ac.rhul.cs2800.model;

/**
 * Represents a grade for a module, including the score and the associated module.
 */
public class Grade {
  private int score;
  private Module module;

  /**
   * Default constructor initialising a grade with default values.
   */
  public Grade() {
    this(0, null); // Default score is 0 and no associated module
  }

  /**
   * Constructor that sets the grade score, defaulting module to null.
   *
   * @param score the score of the grade
   */
  public Grade(int score) {
    this(score, null); 
  }

  /**
   * Constructor that sets both the score and the module.
   *
   * @param score the score 
   * @param module the associated module
   */
  public Grade(int score, Module module) {
    setScore(score); // Validate and set score
    this.module = module; 
  }

  /**
   *
   * @return the current score
   */
  public int getScore() {
    return score;
  }

  /**
   * Sets the score after validating its range.
   *
   * @param score 0 <= the new score <=100
   * @throws IllegalArgumentException if score <0 or score > 100
   */
  public void setScore(int score) {
    if (score < 0 || score > 100) {
      throw new IllegalArgumentException("Score must be between 0 and 100");
    }
    this.score = score;
  }

  /**
   * Gets the module associated with this grade.
   *
   * @return the associated module
   */
  public Module getModule() {
    return module;
  }

  // Add additional methods like toString, equals, and hashCode if needed for debugging and storage
}