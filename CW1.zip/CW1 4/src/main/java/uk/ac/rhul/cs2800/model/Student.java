package uk.ac.rhul.cs2800.model;

import java.util.ArrayList;
import java.util.List;
import uk.ac.rhul.cs2800.exception.NoGradeAvailableException;
import uk.ac.rhul.cs2800.exception.NoRegistrationException;

/**
 * Represents a student with personal details, grades, and course registrations.
 */
public class Student {
  private long id;
  private String firstName;
  private String lastName;
  private String username;
  private String email;
  private List<Grade> grades = new ArrayList<>();
  private List<Registration> registrations = new ArrayList<>();

  /**
   * Constructs a student with empty lists for grades and registrations.
   */
  public Student() {}

  /**
   * Computes and returns the average grade.
   *
   * @return average grade value
   * @throws NoGradeAvailableException if no grades are present
   */
  public float computeAverage() throws NoGradeAvailableException {
    if (grades.isEmpty()) {
      throw new NoGradeAvailableException();
    }
    float sum = 0;
    for (Grade grade : grades) {
      sum += grade.getScore();
    }
    return sum / grades.size();
  }

  /**
   * Returns the student's ID.
   *
   * @return the student's ID
   */
  public long getId() {
    return id;
  }

  public void setId(long id) {
    this.id = id;
  }

  public String getFirstName() {
    return firstName;
  }

  public void setFirstName(String firstName) {
    this.firstName = firstName;
  }

  public String getLastName() {
    return lastName;
  }

  public void setLastName(String lastName) {
    this.lastName = lastName;
  }

  public String getUsername() {
    return username;
  }

  public void setUsername(String username) {
    this.username = username;
  }

  public String getEmail() {
    return email;
  }

  public void setEmail(String email) {
    this.email = email;
  }


  public void addGrade(Grade grade) {
    this.grades.add(grade);
  }

  /**
   * Method to get the Grade of the module.
   *
   * @param module the module studied .
   * @return the grade of the module.
   * @throws NoGradeAvailableException if  tehre is no available grade 
   */
  public Grade getGrade(Module module) throws NoGradeAvailableException {
    for (Grade grade : grades) {
      if (grade.getModule().equals(module)) {
        return grade;
      }
    }
    throw new NoGradeAvailableException();
  }

  /**
   * Method to register the student.
   *
   * @param module 
   * @throws NoRegistrationException if the student is already registred.
   */
  public void registerModule(Module module) throws NoRegistrationException {
    for (Registration register : registrations) {
      if (register.getModule().equals(module)) {
        throw new NoRegistrationException();
      }

    }
    registrations.add(new Registration(this, module));
  }

}