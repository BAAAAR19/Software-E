package uk.ac.rhul.cs2800.exception;

// No grades Exception class.
 
public class NoGradeAvailableException extends Exception {
  //the serial ID.
  private static final long serialVersionUID = 1L;
}
