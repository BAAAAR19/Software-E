package uk.ac.rhul.cs2800.model;

/**
 * Represents a module with a code, name, and a boolean status.
 */
public class Module {
  private String code;
  private String name;
  private boolean mnc;

  /**
   * Constructs a new Module with specified code, name, and MNC status.
   *
   * @param code the module code
   * @param name the module name
   * @param mnc the MNC status (true or false)
   */
  public Module(String code, String name, boolean mnc) {
    this.code = code;
    this.name = name;
    this.mnc = mnc;
  }

  /**
   * Default constructor for creating an instance without initial values.
   */
  public Module() {
    // Initialises with default values
    this.code = "";
    this.name = "";
    this.mnc = false;
  }

  /**
   * Returns the module code.
   *
   * @return the code of the module
   */
  public String getCode() {
    return code;
  }

  /**
   * Sets the module code.
   *
   * @param code the new code of the module
   */
  public void setCode(String code) {
    this.code = code;
  }

  /**
   * Returns the name of the module.
   *
   * @return the name of the module
   */
  public String getName() {
    return name;
  }

  /**
   *
   *
   * @param name the new name of the module
   */
  public void setName(String name) {
    this.name = name;
  }

  /**
   * Checks if the module has MNC status.
   *
   * @return true if the module has MNC status, else false
   */
  public boolean isMnc() {
    return mnc;
  }

  /**
   * Sets the MNC status of the module.
   *
   * @param mnc 
   */
  public void setMnc(boolean mnc) {
    this.mnc = mnc;
  }
}
